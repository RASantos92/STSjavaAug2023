package com.robert.inheritancedemo;

public class Test {

	public static void main(String[] args) {
		Developer dev = new Developer();

        Developer dev1 = new Developer("Isaiah Tran",24,120000.45);
        System.out.println(dev);

        dev.setName("Kyle Smyth");
        dev.setAge(26) ;
        dev.setSalary(120000.23) ;
        dev.addLanguage("Python");
        dev.addLanguage("Java");
        
//        dev.displayStatus();
//        System.out.println("***********************************\n");
//        dev1.displayStatus();
//        System.out.println(Developer.getDevCount());
//        System.out.println(Developer.getTotalSalary());
        
        
        FrontEndDev frontEndDev = new FrontEndDev("John");
        frontEndDev.displayStatus();
     
	}

}
